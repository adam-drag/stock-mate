Lambda package for event emitter API
